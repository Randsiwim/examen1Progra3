const express = require('express'); 
const bodyParser = require('body-parser');
const cors = require('cors');
const sql = require('mssql');


const dbConfig = {
        user: 'rand',
        password: 'Password123', 
        server: 'localhost', 
        port: 1433,
        database: 'gestionreciclaje',
        options: {
            encrypt: false,
            trustServerCertificate: true   
        }
    };
    
async function connectToDatabase() {
    try {
        let pool = await sql.connect(dbConfig);
        console.log("Conectado a SQL Server exitosamente");
        return pool;
    } catch (err) {
        console.error("Error conectándose a la base de datos: ", err);
    }
}

connectToDatabase();

const app = express();
app.use(bodyParser.json());
app.use(cors());

app.post('/usuarios', (req, res) => {
    const { nombre, correo, telefono } = req.body;
    
    if (!nombre || !correo || !telefono) {
        return res.status(400).json({ error: 'Faltan datos' });
    }

    const query = `INSERT INTO usuarios (nombre, correo, telefono) VALUES (@nombre, @correo, @telefono)`;

    const request = new sql.Request();
    request.input('nombre', sql.VarChar, nombre)
           .input('correo', sql.VarChar, correo)
           .input('telefono', sql.VarChar, telefono)
           .query(query, (err, result) => {
               if (err) {
                   console.log(err);
                   return res.status(500).send('Error al registrar el usuario');
               } 
               res.send('Usuario registrado correctamente');
           });
});

app.post('/reciclajes', (req, res) => {
    const { id_usuario, id_centro, tipo_material, peso_kg } = req.body;
    let puntos = 0;

    if (tipo_material === 'Plástico') puntos = peso_kg * 8;
    else if (tipo_material === 'Papel') puntos = peso_kg * 5;
    else if (tipo_material === 'Vidrio') puntos = peso_kg * 10;

    const query = `INSERT INTO reciclajes (id_usuario, id_centro, tipo_material, peso_kg, fecha_reciclaje, puntos)
                   VALUES (@id_usuario, @id_centro, @tipo_material, @peso_kg, GETDATE(), @puntos)`;

    const request = new sql.Request();
    request.input('id_usuario', sql.Int, id_usuario)
           .input('id_centro', sql.Int, id_centro)
           .input('tipo_material', sql.VarChar, tipo_material)
           .input('peso_kg', sql.Float, peso_kg)
           .input('puntos', sql.Int, puntos)
           .query(query, (err, result) => {
               if (err) {
                   console.log(err);
                   return res.status(500).send('Error al registrar el reciclaje');
               } 
               res.send('Reciclaje registrado correctamente');
           });
});

app.get('/estadisticas', async (req, res) => {
    try {
        const pool = await connectToDatabase();
        const result = await pool.request().query("SELECT id_usuario, SUM(puntos) AS total_puntos FROM reciclajes GROUP BY id_usuario");
        res.json(result.recordset); // Devuelve los resultados en formato JSON
    } catch (err) {
        console.error(err);
        res.status(500).send('Error al obtener estadísticas');
    }
});


app.listen(3000, () => {
    console.log('Servidor ejecutándose en el puerto 3000');
});
