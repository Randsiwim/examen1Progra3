// Registro de usuarios
document.getElementById('registroForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const correo = document.getElementById('correo').value;
    const telefono = document.getElementById('telefono').value;

    fetch('http://127.0.0.1:3000/usuarios', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nombre, correo, telefono })
    })
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => console.error('Error:', error));
});

// Registro de reciclaje
document.getElementById('reciclajeForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const id_usuario = document.getElementById('usuario').value;
    const id_centro = document.getElementById('centro').value;
    const tipo_material = document.getElementById('material').value;
    const peso_kg = document.getElementById('peso').value;

    fetch('http://127.0.0.1:3000/reciclajes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id_usuario, id_centro, tipo_material, peso_kg })
    })
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => console.error('Error:', error));
});

document.addEventListener('DOMContentLoaded', () => {
    fetch('http://127.0.0.1:3000/estadisticas')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            const estadisticasDiv = document.getElementById('estadisticas');
            if (data.length === 0) {
                estadisticasDiv.innerHTML = '<p>No hay datos de reciclaje disponibles.</p>';
            } else {
                const table = document.createElement('table');
                table.innerHTML = `
                    <tr>
                        <th>ID Usuario</th>
                        <th>Puntos Acumulados</th>
                    </tr>
                `;
                data.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.id_usuario}</td>
                        <td>${item.total_puntos}</td>
                    `;
                    table.appendChild(row);
                });
                estadisticasDiv.appendChild(table);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('estadisticas').innerHTML = '<p>Error al cargar estadísticas.</p>';
        });
});

